import { Component, OnInit } from '@angular/core';
import{CustomerService} from '../customer.service';
import {Router} from '@angular/router';


@Component({
  selector: 'app-uploadproducts',
  templateUrl: './uploadproducts.component.html',
  styleUrls: ['./uploadproducts.component.css']
})
export class UploadproductsComponent implements OnInit {
product:any;
imageUrl:any;
contact:any;

  fileToUpload:File=null;
  reader:FileReader;
  constructor(private router:Router, private service: CustomerService) { 
    this.imageUrl='/assets/images/1.jpg';

    this.contact={state:'',  mobile:''};

  }

  ngOnInit(): void {
  }

addcontacts(registerForm:any):void{
    this.service.addcontacts(this.contact).subscribe((result:any) =>{console.log(result);});
    alert("contact stored");
}

}