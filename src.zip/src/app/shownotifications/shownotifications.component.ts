import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-shownotifications',
  templateUrl: './shownotifications.component.html',
  styleUrls: ['./shownotifications.component.css']
})
export class ShownotificationsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
