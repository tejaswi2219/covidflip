import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ShownotificationsComponent } from './shownotifications.component';

describe('ShownotificationsComponent', () => {
  let component: ShownotificationsComponent;
  let fixture: ComponentFixture<ShownotificationsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ShownotificationsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ShownotificationsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
