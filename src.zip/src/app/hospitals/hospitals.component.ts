import { Component, OnInit } from '@angular/core';
import{CustomerService} from '../customer.service';
import {Router} from '@angular/router';


@Component({
  selector: 'app-hospitals',
  templateUrl: './hospitals.component.html',
  styleUrls: ['./hospitals.component.css']
})

export class HospitalsComponent implements OnInit {
  hospital:any;
  constructor(private router:Router, private service: CustomerService) { 
    this.hospital={state:'',  ruralhospitals:'',ruralbeds:'',urbanhospitals:'',urbanbeds:'',totalhospitals:'',totalbeds:''};
  }

  ngOnInit(): void {
  }
  addhospitals(registerForm:any):void{
    this.service.addhospitals(this.hospital).subscribe((result:any) =>{console.log(result);});
    alert("contact stored");
}

}
