import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ShowhospitalComponent } from './showhospital.component';

describe('ShowhospitalComponent', () => {
  let component: ShowhospitalComponent;
  let fixture: ComponentFixture<ShowhospitalComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ShowhospitalComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ShowhospitalComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
