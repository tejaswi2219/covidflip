import { Component, OnInit } from '@angular/core';
import{CustomerService} from '../customer.service';
import {Router} from '@angular/router';
@Component({
  selector: 'app-notifications',
  templateUrl: './notifications.component.html',
  styleUrls: ['./notifications.component.css']
})
export class NotificationsComponent implements OnInit {
notification:any;
  constructor(private router:Router, private service: CustomerService) {
    this.notification={date:'',  title:''};
   }

  ngOnInit(): void {
  }
  addnotifications(registerForm:any):void{
    this.service.addcontacts(this.notification).subscribe((result:any) =>{console.log(result);});
    alert("contact stored");
}

}
