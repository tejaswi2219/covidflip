import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import {FormsModule} from '@angular/forms';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { LoginComponent } from './login/login.component';
import { HomeComponent } from './home/home.component';
import { HeaderComponent } from './header/header.component';
import { FooterComponent } from './footer/footer.component';
import {HttpClientModule} from '@angular/common/http';
import {RouterModule ,Routes} from '@angular/router';
import { AuthGuard } from './auth.guard';
import { UploadproductsComponent } from './uploadproducts/uploadproducts.component';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { ToastrModule } from 'ngx-toastr';
import { ContactComponent } from './contact/contact.component';
import { NotificationsComponent } from './notifications/notifications.component';
import { HospitalsComponent } from './hospitals/hospitals.component';
import { ShowcontactComponent } from './showcontact/showcontact.component';
import { ShowhospitalComponent } from './showhospital/showhospital.component';
import { ShownotificationsComponent } from './shownotifications/shownotifications.component';
const appRoot: Routes = [{ path: '', component: HomeComponent },
  { path: 'login', component: LoginComponent },
  { path: 'showcontact', component: ShowcontactComponent },
  { path: 'shownotifications', component: ShownotificationsComponent },
  { path: 'showhospital', component: ShowhospitalComponent },
  { path: 'notifications', component: NotificationsComponent },
  { path: 'hospitals', component: HospitalsComponent },
  { path: 'contact', component: ContactComponent },
  { path: 'home', canActivate:[AuthGuard],component: HomeComponent },
  {path:'uploadproducts',canActivate:[AuthGuard],component:UploadproductsComponent},


]
@NgModule({
  declarations: [
    AppComponent,
    
    
    LoginComponent,
    HomeComponent,
    HeaderComponent,
    FooterComponent,
    UploadproductsComponent,
    ContactComponent,
    NotificationsComponent,
    HospitalsComponent,
    ShowcontactComponent,
    ShowhospitalComponent,
    ShownotificationsComponent,
    
  ],
  imports: [

    BrowserModule,FormsModule,
    RouterModule.forRoot(appRoot),
    HttpClientModule,
    BrowserAnimationsModule,
	ToastrModule.forRoot()
  ],
  providers: [AuthGuard],
  bootstrap: [AppComponent]
})
export class AppModule { }
