import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-showcontact',
  templateUrl: './showcontact.component.html',
  styleUrls: ['./showcontact.component.css']
})
export class ShowcontactComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
