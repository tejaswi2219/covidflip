import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Subject } from 'rxjs';

@Injectable({
  providedIn: 'root'
})

export class CustomerService {
  contact:any;
  notification:any;
  hospital:any;
  
  constructor(private httpClient:HttpClient) {

    
    
  }
  addcontacts(contact:any){
    return this.httpClient.post('RESTAPI2018/webapi/myresource1/contact',contact);
  }
  addnotifications(notification:any){
    return this.httpClient.post('RESTAPI2018/webapi/myresource1/notification',notification);
  }
  addhospitals(hospital:any){
    return this.httpClient.post('RESTAPI2018/webapi/myresource1/hospital',hospital);
  }
  

}
