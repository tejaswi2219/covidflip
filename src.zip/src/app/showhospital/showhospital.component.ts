import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-showhospital',
  templateUrl: './showhospital.component.html',
  styleUrls: ['./showhospital.component.css']
})
export class ShowhospitalComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
