import { Component, OnInit } from '@angular/core';
import{CustomerService} from '../customer.service';
import { Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
declare var toastr:any;
@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  customer:any;
  user :any;
  constructor(private toastr: ToastrService,private router:Router,private customerService: CustomerService) { 
    this.user ={username:'',password:''};

  }


  ngOnInit(): void {
  }
  loginUser():void{
    console.log('loginUser method called');
    console.log(this.user);
  
  }
  validateUser(loginForm:any){
      if(loginForm.username==='admin' && loginForm.password==='admin'){
        this.toastr.success("Successfully Login!!") 

        this.router.navigate(['uploadproducts']);
      }
    
        
        else{
          this.toastr.error("Not Registered!") 
              
        }

      }
  }
 

